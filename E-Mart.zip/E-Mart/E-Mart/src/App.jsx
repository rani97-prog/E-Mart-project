

import React from 'react'
import { Routes,Route } from 'react-router-dom'
import './App.css'

import LandingPage from './stores/pages/LandingPage'
// import Computers from './stores/components/Computers'
import MobilePage from './stores/pages/MobilePage'
import ComputerPage from './stores/pages/ComputerPage'
import WatchPage from './stores/pages/WatchPage'
import MenPage from './stores/pages/MenPage'
import WomenPage from './stores/pages/WomenPage'
import FurniturePage from './stores/pages/FurniturePage'
import AcPage from './stores/pages/AcPage'
import KitchenPage from './stores/pages/KitchenPage'
import FridgePage from './stores/pages/FridgePage'
import BooksPage from './stores/pages/BooksPage'
import MobileSingle from './singles/MobileSingle'
import ComputerSingle from './singles/ComputerSingle'
import WatchSingle from './singles/WatchSingle'
import MenSingle from './singles/MenSingle'
import WomenSingle from './singles/WomenSingle'
import FurnitureSingle from './singles/FurnitureSingle'
import AcSingle from './singles/AcSingle'
import KitchenSingle from './singles/KitchenSingle'
import FridgeSingle from './singles/FridgeSingle'
import BookSingle from './singles/BookSingle'
import UserCart from './stores/UserCart'
import Footer from './stores/components/Footer'; 
import SignInPage from "./stores/pages/SignInPage";


const App = () => {
  return (
    <div>
      <Routes>
       <Route path='/' element = {<LandingPage/>} />
       <Route path='/mobiles' element ={<MobilePage/>}/>
       <Route path='/computers' element={<ComputerPage/>}/>
       <Route path='/watches' element ={<WatchPage/>}/>
       <Route path='/men' element={<MenPage/>}/>
       <Route path='/women' element={<WomenPage/>}/>
       <Route path='/furniture' element={<FurniturePage/>}/>
      <Route path='/ac' element={<AcPage/>}/>
      <Route path='/kitchen' element={<KitchenPage/>}/>
      <Route path='/fridge' element={<FridgePage/>}/>
      <Route path='/books' element={<BooksPage/>}/>
      <Route path='/mobiles/:id' element={<MobileSingle/>} />
      <Route path='/computers/:id' element={<ComputerSingle/>}/>
      <Route path='/watches/:id' element={<WatchSingle/>}/>
      <Route path='/men/:id' element={<MenSingle/>}/>
      <Route path='/women/:id' element ={<WomenSingle/>}/>
      <Route path='/furniture/:id' element={<FurnitureSingle/>}/>
      <Route path='/ac/:id' element={<AcSingle/>}/>
      <Route path='/kitchen/:id' element={<KitchenSingle/>}/>
      <Route path='/fridge/:id' element={<FridgeSingle/>}/>
      <Route path='/books/:id' element={<BookSingle/>}/>
      <Route path='/cart' element ={<UserCart/>} />
      </Routes>
      
      <div>
        <Routes>
  {/* your existing routes */}
  <Route path="/signin" element={<SignInPage />} />
</Routes>
      </div>
      <Footer />
    </div>
  )
}

export default App
 