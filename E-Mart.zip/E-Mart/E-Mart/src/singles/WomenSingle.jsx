import React from 'react'
import { womanData } from '../stores/data/woman'
import { useParams } from 'react-router-dom'
import Navbar from '../stores/components/Navbar'

import { useCart } from '../stores/Context/CartContext'

const WomenSingle = () => {
    const {id} = useParams()
    const {addToCart, cartItems} = useCart()

                const product = womanData.find((item)=>item.id ===id)
                console.log(id);
  return (
     <>
    <Navbar/>
   <div className="ind-page">
    <div className="ind-image">
     <img src={product.image} alt="" />   
    </div>
    <div className="ind-details">
        <div className="ind-model">
       <h3>{product.model}</h3> 
    </div>
    <div className="ind-price">
        <h2>{product.price}</h2>
    </div>
    <div className="ind-price">
        <h2>{product.company}</h2>
    </div>
    <div className="ind-desc">
        <p>
            {product.description}
        </p>
        <div className='btn'>
            <button onClick={()=>addToCart(product)}>Add TO Cart</button>
        </div>
    </div>
    </div>
   </div>
    
    </>
  )
}

export default WomenSingle
