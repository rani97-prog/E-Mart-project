

import React from 'react';


const Footer = () => {
  return (
    <footer className="footer">
      <p>© 2025 E-Mart. All rights reserved.</p>
      <p>Contact us: support@emart.com</p>
    </footer>
  );
};

export default Footer;
