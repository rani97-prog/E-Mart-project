

import React from 'react'
import Mobiles from './Mobiles'
import Computers from './Computers'
import Watch from './Watch'
import Men from './Mens'
import Women from './Womens'
import Furniture from './Furnitures'
import Ac from './Ac'
import Kitchen from './Kitchen'
import Tv from './Tv'
import Fridge from './Fridge'
import Books from './Books'



const products = () => {
  return (
    <div>
    <Mobiles/>
    <Computers/>
    <Watch/>
    <Men/>
    <Women/>
    <Furniture/>
    <Ac/>
    <Kitchen/>
    <Tv/>
    <Fridge/>
    <Books/>
    
    
    </div>
  )
}

export default products
