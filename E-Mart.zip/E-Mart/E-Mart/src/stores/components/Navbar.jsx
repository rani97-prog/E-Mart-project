

import React from 'react'
import { Link } from "react-router-dom";

import { useCart } from '../Context/CartContext';
import { useAuth } from '../Context/AuthContext';


const Navbar = () => {

  const {cartItems} = useCart()

  const { isLoggedIn, signIn, signOut } = useAuth(); 
 
  return (
   <>
    <div className='navSection'>
    <div className='title'>
        
    <h1> 🛍️ E-Mart</h1>
    </div>
    {/* <div className='search'>
        <input type="text" placeholder='Search...' />
    </div> */}
    <div className='user'>
      <div className="homepage">
          
          <Link to= '/' style={{ textDecoration: 'none', color: 'inherit' }}>
          <h3>Home</h3>
          </Link>
          </div>
        <Link to ='/signin' className="auth-link">
        <div className='user-detail'><h3 style={{ cursor: "pointer" }}  > SignIN/SignOut
 </h3>   </div>
        </Link>
        <Link to= '/cart' style={{ textDecoration: 'none', color: 'inherit' }}>
        <div className='cart'> <h3>🛒 Cart      <span > 
              {cartItems.length}
            </span> 
             </h3></div>
        </Link>
        
      
    </div>
    </div>
    <div className="subMenu">
      <ul>
       <Link to='/mobiles'
       style={{ textDecoration: 'none' }}><li> Mobiles</li></Link>
       <Link to='/computers' style={{ textDecoration: 'none' }}>
       <li>Computers</li>
       </Link>
       <Link to='/watches' style={{ textDecoration: 'none' }}><li> Watches</li></Link>
      <Link to='/men' style={{ textDecoration: 'none' }}><li> Men Fashion</li></Link>
     <Link to='/women' style={{ textDecoration: 'none' }}><li>Woman Dressing</li></Link>
       <Link to='/furniture' style={{ textDecoration: 'none' }}><li>Furniture</li></Link>
       <Link to='/AC' style={{ textDecoration: 'none' }}><li>Air conditioners</li></Link>
       <Link to='/kitchen' style={{ textDecoration: 'none' }}><li>Kitchen</li></Link> 
       <Link to='/fridge' style={{ textDecoration: 'none' }}><li>Fridge</li></Link>
       <Link to='/books' style={{ textDecoration: 'none' }}><li>Books</li></Link>
      </ul>
    </div>
   </>
  
  )
}

export default Navbar
