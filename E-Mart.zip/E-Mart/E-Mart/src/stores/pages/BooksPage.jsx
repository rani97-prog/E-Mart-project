// import React from 'react'
// import { booksData } from '../data/books'
// import Navbar from '../components/Navbar'
// import { Link } from 'react-router-dom'

// const BooksPage = () => {
//   return (
//     <>
//     <Navbar/>
//     <div className='pageSection'>
//      {booksData.map((item)=>{
//         return(
//             <div>
//               <Link to={`/books/${item.id}`}>
//               <div className="pageImage">
//                 <img src={item.image} alt="" />
//                 </div>
//               </Link> 
//                  <div className="proModel">
//                   {item.company}, {item.model}  
//                  </div>
//             </div>
//         )
//      })} 
//     </div>
//     </>
//   )
// }

// export default BooksPage



import React, { useState } from 'react';
import { booksData } from '../data/books';
import Navbar from '../components/Navbar';
import { Link } from 'react-router-dom';

const BooksPage = () => {
  const [selectedAuthors, setSelectedAuthors] = useState([]);

  const uniqueAuthors = [...new Set(booksData.map(item => item.author))];

  const handleAuthorClick = (author) => {
    if (selectedAuthors.includes(author)) {
      setSelectedAuthors(selectedAuthors.filter(a => a !== author));
    } else {
      setSelectedAuthors([...selectedAuthors, author]);
    }
  };

  const filteredItems =
    selectedAuthors.length === 0
      ? booksData
      : booksData.filter(item => selectedAuthors.includes(item.author));

  return (
    <>
      <Navbar />

      <div className="computerPage-container">
        {/* Sidebar */}
        <div className="sidebar">
          {uniqueAuthors.map((author, index) => (
            <div key={index} className="sidebar-option">
              <label>
                <input
                  type="checkbox"
                  checked={selectedAuthors.includes(author)}
                  onChange={() => handleAuthorClick(author)}
                />
                {author}
              </label>
            </div>
          ))}
        </div>

        {/* Product Cards */}
        <div className="products">
          {filteredItems.map((item) => (
            <div key={item.id} className="product-card">
              <Link to={`/books/${item.id}`}>
                <div className="product-image">
                  <img src={item.image} alt={item.title} />
                </div>
              </Link>
              <div className="product-info">
                <strong>{item.title}</strong><br />
                {item.author}<br />
                ₹{item.price}
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default BooksPage;
