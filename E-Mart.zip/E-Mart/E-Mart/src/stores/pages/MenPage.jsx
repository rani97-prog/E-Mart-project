// import React from 'react'
// import { menData } from '../data/men'
// import Navbar from '../components/Navbar'
// import { Link } from 'react-router-dom'

// const MenPage = () => {
//   return (
//     <>
//     <Navbar/>
//     <div className='pageSection'>
//      {menData.map((item)=>{
//         return(
//             <div>
//               <Link to={`/mens/${item.id}`}>
//               <div className="pageImage">
//                 <img src={item.image} alt="" 
//                 style={{ width: '200px', height: '250px', objectFit: 'cover', borderRadius: '10px' }}/>
//                 </div> 
//                 </Link>
//                  <div className="proModel">
//                   {item.company}, {item.model}  
//                  </div>
//             </div>
//         )
//      })} 
//     </div>
//     </>
//   )
// }

// export default MenPage




import React, { useState } from 'react';
import { menData } from '../data/men'; // update path as needed
import Navbar from '../components/Navbar';
import { Link } from 'react-router-dom';

const MenPage = () => {
  const [selectedBrands, setSelectedBrands] = useState([]);

  const uniqueBrands = [...new Set(menData.map(item => item.brand))];

  const handleBrandClick = (brand) => {
    if (selectedBrands.includes(brand)) {
      setSelectedBrands(selectedBrands.filter(item => item !== brand));
    } else {
      setSelectedBrands([...selectedBrands, brand]);
    }
  };

  const filteredMen =
    selectedBrands.length === 0
      ? menData
      : menData.filter(item => selectedBrands.includes(item.brand));

  return (
    <>
      <Navbar />

      <div className="computerPage-container">
        {/* Sidebar brand filter */}
        <div className="sidebar">
          {uniqueBrands.map((brand, index) => (
            <div key={index} className="sidebar-option">
              <label>
                <input
                  type="checkbox"
                  checked={selectedBrands.includes(brand)}
                  onChange={() => handleBrandClick(brand)}
                />
                {brand}
              </label>
            </div>
          ))}
        </div>

        {/* Product display */}
        <div className="products">
          {filteredMen.map((item) => (
            <div key={item.id} className="product-card">
              <Link to={`/men/${item.id}`}>
                <div className="product-image">
                  <img src={item.image} alt={item.model} />
                </div>
              </Link>
              <div className="product-info">
                {item.brand}, {item.model}, ₹{item.price}
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default MenPage;

