
// import React, {useState} from 'react'
// import{computerData} from '../data/computers'
// import Navbar from '../components/Navbar'
// import { Link } from 'react-router-dom'

// const ComputerPage = () => {

// const [selectedProduct, setselectedProduct]= useState([])

// const companyHandler =(mango)=>{
//   if ( selectedProduct.includes(mango)){
//     setselectedProduct(selectedProduct.filter(item => item !== mango))
 
//   } else{
//     setselectedProduct([mango])
//   }
// }
//   return (
//     <>
//     <Navbar/>
//     <div className='pro-selected'>
//       {computerData.map((phone)=>{
//         return(
//           <div>
//             <label>
//               <input type="checkbox"
//               checked = {selectedProduct.includes(phone.company)}
//               onChange={()=>companyHandler(phone.company)} />
              
//              {phone.company}
//             </label>
//           </div>
//         )
//       })}
//     </div>

//     <div className='pageSection'>
//      {computerData.map((item)=>{
//         return(
//             <div>
//               <Link to={`/computers/${item.id}`}>
//               <div className="pageImage">
//                 <img src={item.image} alt="" />
//                 </div> 
//               </Link>
//                  <div className="proModel">
//                   {item.company}, {item.model}  
//                  </div>
//             </div>
//         )
//      })} 
//     </div>
//     </>
//   )
// }

// export default ComputerPage



import React, { useState } from 'react';
import { computerData } from '../data/computers';
import Navbar from '../components/Navbar';
import { Link } from 'react-router-dom';


const ComputerPage = () => {
  const [selectedBrands, setSelectedBrands] = useState([]);

  const uniqueBrands = [...new Set(computerData.map(item => item.company))];

  const handleBrandClick = (brand) => {
    if (selectedBrands.includes(brand)) {
      setSelectedBrands(selectedBrands.filter(item => item !== brand));
    } else {
      setSelectedBrands([...selectedBrands, brand]);
    }
  };

  const filteredComputers =
    selectedBrands.length === 0
      ? computerData
      : computerData.filter(item => selectedBrands.includes(item.company));

  return (
    <>
      <Navbar />

      <div className="computerPage-container">
        {/* Sidebar brand filter */}
        <div className="sidebar">
          {uniqueBrands.map((brand, index) => (
            <div key={index} className="sidebar-option">
              <label>
                <input
                  type="checkbox"
                  checked={selectedBrands.includes(brand)}
                  onChange={() => handleBrandClick(brand)}
                />
                {brand}
              </label>
            </div>
          ))}
        </div>

        {/* Product display */}
        <div className="products">
          {filteredComputers.map((item) => (
            <div key={item.id} className="product-card">
              <Link to={`/computers/${item.id}`}>
                <div className="product-image">
                  <img src={item.image} alt={item.model} />
                </div>
              </Link>
              <div className="product-info">
                {item.company}, {item.model}
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default ComputerPage;
