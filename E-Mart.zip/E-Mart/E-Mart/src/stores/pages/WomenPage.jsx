// import React from 'react'
// import{womanData}from '../data/woman'
// import Navbar from '../components/Navbar'
// import { Link, Links } from 'react-router-dom'
// const WomenPage = () => {
//   return (
//     <>
//     <Navbar/>
//     <div className='pageSection'>
//      {womanData.map((item)=>{
//         return(
//             <div>
//               <Link to ={`/womens/${item.id}`}>
//               <div className="pageImage">
//                 <img src={item.image} alt="" 
//                 style={{ width: '200px', height: '250px', objectFit: 'cover', borderRadius: '10px'}}/>
//                 </div> 
//               </Link>
//                  <div className="proModel">
//                   {item.company}, {item.model},{item.price}  
//                  </div>
//             </div>
//         )
//      })} 
//     </div>
//     </>
//   )
// }

// export default WomenPage


import React, { useState } from 'react';
import { womanData } from '../data/woman';
import Navbar from '../components/Navbar';
import { Link } from 'react-router-dom';

const WomenPage = () => {
  const [selectedBrands, setSelectedBrands] = useState([]);

  const uniqueBrands = [...new Set(womanData.map(item => item.brand))];

  const handleBrandClick = (brand) => {
    if (selectedBrands.includes(brand)) {
      setSelectedBrands(selectedBrands.filter(item => item !== brand));
    } else {
      setSelectedBrands([...selectedBrands, brand]);
    }
  };

  const filteredWomen =
    selectedBrands.length === 0
      ? womanData
      : womanData.filter(item => selectedBrands.includes(item.brand));

  return (
    <>
      <Navbar />

      <div className="computerPage-container">
        {/* Sidebar for brand filter */}
        <div className="sidebar">
          {uniqueBrands.map((brand, index) => (
            <div key={index} className="sidebar-option">
              <label>
                <input
                  type="checkbox"
                  checked={selectedBrands.includes(brand)}
                  onChange={() => handleBrandClick(brand)}
                />
                {brand}
              </label>
            </div>
          ))}
        </div>

        {/* Product Cards */}
        <div className="products">
          {filteredWomen.map((item) => (
            <div key={item.id} className="product-card">
              <Link to={`/women/${item.id}`}>
                <div className="product-image">
                  <img src={item.image} alt={item.model} />
                </div>
              </Link>
              <div className="product-info">
                {item.brand}, {item.model}
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default WomenPage;

