// import React from 'react'
// import{kitchenData}from '../data/kitchen'
// import Navbar from '../components/Navbar'
// import { Link } from 'react-router-dom'

// const KitchenPage = () => {
//   return (
//     <>
//     <Navbar/>
//     <div className='pageSection'>
//      {kitchenData.map((item)=>{
//         return(
//             <div>
//               <Link to={`/kitchens/${item.id}`}>
//               <div className="pageImage">
//                 <img src={item.image} alt="" />
//                 </div> 
//               </Link>
//                  <div className="proModel">
//                   {item.company}, {item.model}  
//                  </div>
//             </div>
//         )
//      })} 
//     </div>
//     </>
//   )
// }

// export default KitchenPage



import React, { useState } from 'react';
import { kitchenData } from '../data/kitchen';
import Navbar from '../components/Navbar';
import { Link } from 'react-router-dom';

const KitchenPage = () => {
  const [selectedBrands, setSelectedBrands] = useState([]);

  const uniqueBrands = [...new Set(kitchenData.map(item => item.brand))];

  const handleBrandClick = (brand) => {
    if (selectedBrands.includes(brand)) {
      setSelectedBrands(selectedBrands.filter(b => b !== brand));
    } else {
      setSelectedBrands([...selectedBrands, brand]);
    }
  };

  const filteredItems =
    selectedBrands.length === 0
      ? kitchenData
      : kitchenData.filter(item => selectedBrands.includes(item.brand));

  return (
    <>
      <Navbar />

      <div className="computerPage-container">
        {/* Sidebar filter */}
        <div className="sidebar">
          {uniqueBrands.map((brand, index) => (
            <div key={index} className="sidebar-option">
              <label>
                <input
                  type="checkbox"
                  checked={selectedBrands.includes(brand)}
                  onChange={() => handleBrandClick(brand)}
                />
                {brand}
              </label>
            </div>
          ))}
        </div>

        {/* Product display */}
        <div className="products">
          {filteredItems.map((item) => (
            <div key={item.id} className="product-card">
              <Link to={`/kitchen/${item.id}`}>
                <div className="product-image">
                  <img src={item.image} alt={item.model} />
                </div>
              </Link>
              <div className="product-info">
                {item.brand}, {item.model}, ₹{item.price}
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default KitchenPage;
