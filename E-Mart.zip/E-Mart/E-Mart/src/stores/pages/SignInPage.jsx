
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext"; // adjust path

const SignInPage = () => {
  const { signIn } = useAuth();
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = (e) => {
    e.preventDefault();

    // ✅ Validate input (simple check)
    if (email === "" || password === "") {
      alert("Please enter both email and password");
      return;
    }

    // ✅ Simulate login success
    signIn(); // update login status in context
    navigate("/"); // go back to home
  };

  return (
    <div style={styles.container}>
      <h2>Sign In / Sign Up</h2>
      <form onSubmit={handleLogin} style={styles.form}>
        <input
          type="email"
          placeholder="Enter your email"
          value={email}
          style={styles.input}
          onChange={(e) => setEmail(e.target.value)}
        />

        <input
          type="password"
          placeholder="Enter your password"
          value={password}
          style={styles.input}
          onChange={(e) => setPassword(e.target.value)}
        />

        <button type="submit" style={styles.button}>Login</button>
      </form>
    </div>
  );
};

export default SignInPage;

const styles = {
  container: {
    textAlign: "center",
    marginTop: "5rem"
  },
  form: {
    display: "flex",
    flexDirection: "column",
    gap: "1rem",
    maxWidth: "300px",
    margin: "0 auto"
  },
  input: {
    padding: "10px",
    fontSize: "16px"
  },
  button: {
    padding: "10px",
    backgroundColor: "#007bff",
    color: "white",
    border: "none",
    cursor: "pointer"
  }
};
