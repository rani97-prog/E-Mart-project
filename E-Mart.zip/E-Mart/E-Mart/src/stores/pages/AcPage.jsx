// import React from 'react'
// import{acData}from '../data/ac'
// import Navbar from '../components/Navbar'
// import { Link } from 'react-router-dom'


// const AcPage = () => {
//   return (
//     <>
//     <Navbar/>
//     <div className='pageSection'>
//      {acData.map((item)=>{
//         return(
//             <div>
//               <Link to={`/ac/${item.id}`}>
//               <div className="pageImage">
//                 <img src={item.image} alt="" />
//                 </div> 
//               </Link>
//                  <div className="proModel">
//                   {item.company}, {item.model}  
//                  </div>
//             </div>
//         )
//      })} 
//     </div>
//     </>
//   )
// }

// export default AcPage


import React, { useState } from 'react';
import { acData } from '../data/ac';
import Navbar from '../components/Navbar';
import { Link } from 'react-router-dom';

const ACPage = () => {
  const [selectedCompanies, setSelectedCompanies] = useState([]);

  const uniqueCompanies = [...new Set(acData.map(item => item.company))];

  const handleCompanyClick = (company) => {
    if (selectedCompanies.includes(company)) {
      setSelectedCompanies(selectedCompanies.filter(item => item !== company));
    } else {
      setSelectedCompanies([...selectedCompanies, company]);
    }
  };

  const filteredACs =
    selectedCompanies.length === 0
      ? acData
      : acData.filter(item => selectedCompanies.includes(item.company));

  return (
    <>
      <Navbar />

      <div className="computerPage-container">
        {/* Sidebar company filter */}
        <div className="sidebar">
          {uniqueCompanies.map((company, index) => (
            <div key={index} className="sidebar-option">
              <label>
                <input
                  type="checkbox"
                  checked={selectedCompanies.includes(company)}
                  onChange={() => handleCompanyClick(company)}
                />
                {company}
              </label>
            </div>
          ))}
        </div>

        {/* Product display */}
        <div className="products">
          {filteredACs.map((item) => (
            <div key={item.id} className="product-card">
              <Link to={`/ac/${item.id}`}>
                <div className="product-image">
                  <img src={item.image} alt={item.model} />
                </div>
              </Link>
              <div className="product-info">
                {item.company}, {item.model}, ₹{item.price}
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default ACPage;
