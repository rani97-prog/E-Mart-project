
// import React from 'react'
// import{watchData} from '../data/watch'
// import Navbar from '../components/Navbar'
// import { Link } from 'react-router-dom'

// const WatchPage = () => {
//   return (
//     <>
//     <Navbar/>
//     <div className='pageSection'>
//      {watchData.map((item)=>{
//         return(
//             <div>
//               <Link to={`/watches/${item.id}`}>
//               <div className="pageImage">
//                 <img src={item.image} alt="" />
//                 </div>
//               </Link> 
//                  <div className="proModel">
//                   {item.company}, {item.model},{item.price} 
//                  </div>
//             </div>
//         )
//      })} 
//     </div>
//     </>
//   )
// }

// export default WatchPage


import React, { useState } from 'react';
import { watchData } from '../data/watch';
import Navbar from '../components/Navbar';
import { Link } from 'react-router-dom';

const WatchPage = () => {
  const [selectedBrands, setSelectedBrands] = useState([]);

  // Get unique brand names from the data
  const uniqueBrands = [...new Set(watchData.map(item => item.brand))];

  // Handle checkbox filter
  const handleBrandToggle = (brand) => {
    if (selectedBrands.includes(brand)) {
      setSelectedBrands(selectedBrands.filter(item => item !== brand));
    } else {
      setSelectedBrands([...selectedBrands, brand]);
    }
  };

  // Filter products based on selected brands
  const filteredWatches =
    selectedBrands.length === 0
      ? watchData
      : watchData.filter(item => selectedBrands.includes(item.brand));

  return (
    <>
      <Navbar />

      <div className="computerPage-container">
        {/* Sidebar for filters */}
        <div className="sidebar">
          {uniqueBrands.map((brand, index) => (
            <div className="sidebar-option" key={index}>
              <label>
                <input
                  type="checkbox"
                  checked={selectedBrands.includes(brand)}
                  onChange={() => handleBrandToggle(brand)}
                />
                {brand}
              </label>
            </div>
          ))}
        </div>

        {/* Product cards */}
        <div className="products">
          {filteredWatches.map((item) => (
            <div className="product-card" key={item.id}>
              <Link to={`/watches/${item.id}`}>
                <div className="product-image">
                  <img src={item.image} alt={item.model} />
                </div>
              </Link>
              <div className="product-info">
                {item.brand}, {item.model}, ₹{item.price}
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default WatchPage;
